
import './App.css';
import React, {useState} from 'react';
import axios from 'axios';


function App() {

  const [pokemons, setPokemons] = useState([])

  const getPokemons = () =>{
    axios.get("https://pokeapi.co/api/v2/pokemon?limit=301")
    .then(res=> {
      console.log(res.data.results)
      setPokemons(res.data.results)
    })
    .catch(err => console.log(err));
  }
  return (
    <div className="App">
      <h2>Pokemon</h2>
      
      <button onClick={getPokemons}>Get Pokemon</button>

      <hr />
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>URL</th>
          </tr>
        </thead>
        <tbody>
          {
            pokemons.map((pokemon, idx) => {
            return (
              <tr key={idx}>
                <td>{pokemon.name}</td>
                <td>{pokemon.url}</td>
              </tr>
            )
          })
        }
        </tbody>
      </table>
    </div>
  );
}

export default App;

